define((require, exports, module) => {
  return () => {
    return {
      duty: {
        finished_at: null
      }
    }
  }
})
