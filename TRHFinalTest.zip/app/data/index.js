define((require, exports, module) => {
  const Plugin = {
    PartyLevel: require('app/plugin/party_level'),
    RepairNotice: require('app/plugin/repair_notice'),
    ForgeNotice: require('app/plugin/forge_notice'),
    HurtNotice: require('app/plugin/hurt_notice')
  }

  return new Vuex.Store({
    namespaced: true,
    state () {
      return {
        inBattle: false,
        dataLoaded: {}
      }
    },
    mutations: {
      inBattle (state) {
        state.inBattle = true
      },
      notInBattle (state) {
        state.inBattle = false
      },
      loadData (state, payload) {
        let { key, loaded } = payload
        Vue.set(state.dataLoaded, key, loaded)
      }
    },
    modules: {
      swords: require('./state/swords'),
      resource: require('./state/resource'),
      duty: require('./state/duty'),
      party: require('./state/party'),
      repair: require('./state/repair'),
      forge: require('./state/forge'),
      player: require('./state/player'),
      equip: require('./state/equip'),
      battle: require('./state/battle'),
      sally: require('./state/sally'),
      notice: require('./state/notice')
    },
    plugins: _.values(Plugin)
  })
})
