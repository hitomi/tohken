define((require, exports, module) => {
  return () => {
    return {
      slot_no: null,
      sword_serial_id: null,
      push_serial_id: null,
      finished_at: null
    }
  }
})
