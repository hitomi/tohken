window.TRHConfig = {
  mode: 'debug'
}
