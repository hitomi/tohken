define((require, exports, module) => {
  return () => {
    return {
      episode_id: null,
      field_id: null,
      party_no: null
    }
  }
})
