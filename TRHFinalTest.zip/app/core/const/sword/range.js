define((require, exports, module) => {
  return {
    '1': '狭',
    '2': '狭',
    '3': '狭',
    '4': '狭',
    '5': '広',
    '6': '縦',
    '7': '横'
  }
})
